const config = window.REVIEW_CONFIG;
const KEY = `influencer-review:${config.datasetId}`;
const seed = window.BERLOOK_DATA || [];
const validHandles = new Set(seed.map(item => item.handle));
let decisions = {};
let dirty = {};
try { dirty = JSON.parse(localStorage.getItem(KEY) || '{}').dirty || {}; } catch {}
let history = [];
let selected = new Set();
let page = 1;
const pageSize = 50;

const nowText = () => new Date().toISOString();
const displayTime = value => value ? new Date(value).toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai', hour12: false }) : '';
document.title = `${config.brand} 资源审核`;
document.querySelector('h1').textContent = document.title;
new ResizeObserver(entries => document.documentElement.style.setProperty('--header-height', `${entries[0].target.offsetHeight}px`)).observe(document.querySelector('header'));

const $ = id => document.getElementById(id);
const esc = value => String(value ?? '').replace(/[&<>"']/g, character => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
})[character]);
const status = handle => decisions[handle]?.status || 'pending';
const priorityOrder = { '高': 0, '中': 1, '低': 2, '': 3 };
let saving = false;
let ready = false;
const saveLabel = document.createElement('span');
saveLabel.setAttribute('role', 'status');
saveLabel.textContent = '正在读取审核记录';
document.querySelector('header nav').prepend(saveLabel);

function cache() {
  try { localStorage.setItem(KEY, JSON.stringify({decisions, dirty})); }
  catch { saveLabel.textContent = '浏览器副本不可用，请检查文件保存状态'; }
}
async function persistDecisions() {
  cache();
  if (saving || !ready) return;
  saving = true;
  try {
    while (Object.keys(dirty).length) {
      const changes = structuredClone(dirty);
      saveLabel.textContent = '正在保存';
    const response = await fetch('/api/review-state', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ datasetId: config.datasetId, changes })
    });
    if (!response.ok) throw new Error('Save failed');
      for (const [handle,value] of Object.entries(changes)) {
        if (JSON.stringify(dirty[handle]) === JSON.stringify(value)) delete dirty[handle];
      }
      cache();
    }
    saveLabel.textContent = '已备份到本地文件';
  } catch {
    saveLabel.textContent = '文件保存失败，变化已暂存；请重试或导出备份';
  } finally { saving = false; }
}

async function restoreDecisions() {
  try {
    const response = await fetch('/api/review-state');
    if (!response.ok) throw new Error('Load failed');
    const state = await response.json();
    if (state.datasetId !== config.datasetId) throw new Error('Wrong dataset');
    decisions = validateDecisions(state.decisions);
    const pending = validateDecisions(dirty);
    dirty = {};
    for (const [handle,value] of Object.entries(pending)) {
      if (decisions[handle] && Date.parse(decisions[handle].at) >= Date.parse(value.at)) continue;
      decisions[handle] = value;
      dirty[handle] = value;
    }
    ready = true;
    if (Object.keys(dirty).length) persistDecisions();
    else {
      cache();
      saveLabel.textContent = state.updatedAt ? '已读取文件记录' : '暂无审核记录';
    }
    render();
  } catch {
    saveLabel.textContent = '记录读取失败，请刷新重试';
  }
}

function validateDecisions(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('Invalid decisions');
  const output = {};
  for (const [handle,item] of Object.entries(value)) {
    if (!validHandles.has(handle)) continue;
    if (!item || !['pending','approved','rejected'].includes(item.status) || !Number.isFinite(Date.parse(item.at))) throw new Error('Invalid decision');
    output[handle] = {status:item.status, at:item.at};
  }
  return output;
}

function changeDecision(handle, value) {
  decisions[handle] = {...value, at:nowText()};
  dirty[handle] = decisions[handle];
}

function filteredRows() {
  const query = $('search').value.trim().toLowerCase();
  const filter = $('filter').value;
  return seed.filter(item => {
    if (filter === 'recommended' && !(status(item.handle) === 'pending' && item.recommended)) return false;
    if (!['all', 'recommended'].includes(filter) && status(item.handle) !== filter) return false;
    const searchable = [item.handle, item.name, item.email, item.country, item.category, item.source].join(' ').toLowerCase();
    return !query || searchable.includes(query);
  }).sort((a, b) => {
    const aStatus = status(a.handle);
    const bStatus = status(b.handle);
    if (aStatus !== bStatus) return aStatus === 'pending' ? -1 : bStatus === 'pending' ? 1 : 0;
    if (Boolean(a.recommended) !== Boolean(b.recommended)) return a.recommended ? -1 : 1;
    return (priorityOrder[a.priority] ?? 3) - (priorityOrder[b.priority] ?? 3) || a.handle.localeCompare(b.handle);
  });
}

function render() {
  const counts = { pending: 0, approved: 0, rejected: 0 };
  seed.forEach(item => counts[status(item.handle)]++);
  $('pending').textContent = counts.pending;
  $('approved').textContent = counts.approved;
  $('rejected').textContent = counts.rejected;
  const done = counts.approved + counts.rejected;
  const percent = seed.length ? Math.round(done / seed.length * 100) : 0;
  $('pct').textContent = `${percent}%`;
  $('progress').style.width = `${percent}%`;

  const rows = filteredRows();
  const pages = Math.max(1, Math.ceil(rows.length / pageSize));
  page = Math.min(page, pages);
  const start = (page - 1) * pageSize;
  const shown = rows.slice(start, start + pageSize);
  const shownHandles = shown.map(item => item.handle);

  $('empty').hidden = rows.length > 0;
  $('tableWrap').hidden = rows.length === 0;
  $('pageInfo').textContent = `第 ${page}/${pages} 页，共 ${rows.length} 条`;
  $('prevBtn').disabled = page <= 1;
  $('nextBtn').disabled = page >= pages;
  $('selectedCount').textContent = `已选 ${selected.size} 条`;
  $('batchApprove').disabled = $('batchReject').disabled = !ready || !selected.size;
  $('undoBtn').disabled = !ready || !history.length;
  const allPageSelected = shown.length > 0 && shownHandles.every(handle => selected.has(handle));
  const somePageSelected = shownHandles.some(handle => selected.has(handle));
  $('selectPageBtn').textContent = allPageSelected ? '取消当前页选择' : '全选当前页';
  $('selectPageBtn').classList.toggle('active', allPageSelected);
  $('selectPageCheckbox').checked = allPageSelected;
  $('selectPageCheckbox').indeterminate = somePageSelected && !allPageSelected;
  $('selectPageCheckbox').disabled = shown.length === 0;

  $('rows').innerHTML = shown.map(item => {
    const itemStatus = status(item.handle);
    const stateText = itemStatus === 'approved' ? '已通过' : itemStatus === 'rejected' ? '不通过' : '待审核';
    const badges = [
      item.recommended ? '<b class="badge recommend">推荐</b>' : '',
      item.priority ? `<b class="badge p-${esc(item.priority)}">${esc(item.priority)}</b>` : '',
      `<b class="badge shipping">${esc(item.shippingStatus || '待确认')}</b>`,
      item.sourceRows > 1 ? `<b class="badge merged">合并${esc(item.sourceRows)}条</b>` : ''
    ].join('');
    return `<tr class="${selected.has(item.handle) ? 'selected' : ''}">
      <td><input class="rowCheck" type="checkbox" data-h="${esc(item.handle)}" ${selected.has(item.handle) ? 'checked' : ''}></td>
      <td class="account"><a href="${esc(item.url)}" target="instagramReview">@${esc(item.handle)}</a><span>${esc(item.name)}</span></td>
      <td>${badges}</td><td>${esc(item.country || '未确认')}</td><td>${esc(item.followers || '')}</td>
      <td class="email">${esc(item.email || '')}</td>
      <td class="reason"><strong>${esc(item.initialLabel || '')}</strong><span>${esc(item.reason || '')}</span><span class="bio">${esc(item.bio || '')}</span></td>
      <td><span class="state ${itemStatus}">${stateText}</span><div class="rowActions"><button type="button" class="rowApprove" data-h="${esc(item.handle)}" title="通过" aria-label="通过 @${esc(item.handle)}">✓</button><button type="button" class="rowReject" data-h="${esc(item.handle)}" title="不通过" aria-label="不通过 @${esc(item.handle)}">×</button></div></td>
    </tr>`;
  }).join('');
}

function applyBatch(newStatus) {
  if (!ready) return;
  const handles = [...selected];
  if (!handles.length) return;
  history.push(handles.map(handle => ({ handle, value: decisions[handle] || null })));
  for (const handle of handles) changeDecision(handle, { status: newStatus });
  persistDecisions();
  selected.clear();
  render();
}

function applySingle(handle, newStatus) {
  if (!ready) return;
  history.push([{ handle, value: decisions[handle] || null }]);
  changeDecision(handle, {status:newStatus});
  persistDecisions();
  selected.delete(handle);
  render();
}

$('filter').value = 'pending';
$('rows').addEventListener('change', event => {
  const checkbox = event.target.closest('.rowCheck');
  if (!checkbox) return;
  if (checkbox.checked) selected.add(checkbox.dataset.h); else selected.delete(checkbox.dataset.h);
  render();
});
$('rows').addEventListener('click', event => {
  const approve = event.target.closest('.rowApprove');
  const reject = event.target.closest('.rowReject');
  if (approve || reject) applySingle((approve || reject).dataset.h, approve ? 'approved' : 'rejected');
});
function toggleCurrentPage() {
  const rows = filteredRows();
  const start = (page - 1) * pageSize;
  const currentPage = rows.slice(start, start + pageSize);
  const allSelected = currentPage.length > 0 && currentPage.every(item => selected.has(item.handle));
  for (const item of currentPage) {
    if (allSelected) selected.delete(item.handle); else selected.add(item.handle);
  }
  render();
}
$('selectPageBtn').onclick = toggleCurrentPage;
$('selectPageCheckbox').onclick = toggleCurrentPage;
$('clearSelection').onclick = () => { selected.clear(); render(); };
$('batchApprove').onclick = () => applyBatch('approved');
$('batchReject').onclick = () => applyBatch('rejected');
$('search').addEventListener('input', () => { page = 1; selected.clear(); render(); });
$('filter').addEventListener('change', () => { page = 1; selected.clear(); render(); });
$('prevBtn').onclick = () => { if (page > 1) page--; render(); window.scrollTo(0, 0); };
$('nextBtn').onclick = () => { page++; render(); window.scrollTo(0, 0); };
$('undoBtn').onclick = () => {
  if (!ready) return;
  const latest = history.pop();
  if (!latest) return;
  for (const entry of latest) {
    changeDecision(entry.handle, entry.value || {status:'pending'});
  }
  persistDecisions();
  render();
};
$('resetBtn').onclick = () => {
  if (!ready) return;
  if (!confirm('确定将当前名单全部恢复为待审核？将先下载备份。')) return;
  exportBackup();
  for (const item of seed) changeDecision(item.handle, {status:'pending'});
  history = [];
  selected.clear();
  persistDecisions();
  render();
};
function downloadCsv(header, rows, filename) {
  const lines = [header, ...rows].map(row => row.map(value => {
    let text = String(value ?? '');
    if (/^[\s]*[=+@-]/.test(text)) text = "'" + text;
    return `"${text.replaceAll('"', '""')}"`;
  }).join(','));
  const anchor = document.createElement('a');
  const url = URL.createObjectURL(new Blob(['\ufeff' + lines.join('\n')], { type: 'text/csv;charset=utf-8' }));
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}
$('exportBtn').onclick = () => {
  const header = ['更新日期（北京时间）', 'Instagram账号', '主页URL', '姓名', '邮箱', '粉丝数', '国家', '来源名单', '判断结果'];
  const approvedRows = seed.filter(item => status(item.handle) === 'approved');
  downloadCsv(header, approvedRows.map(item => [displayTime(decisions[item.handle]?.at), item.handle, item.url, item.name || item.handle, item.email || '', item.followers || '', item.country || '', item.source || '', '最终选中']), `${config.brand}_人工审核通过.csv`);
};
$('exportAllBtn').onclick = () => {
  const header = ['更新日期（北京时间）', 'Instagram账号', '主页URL', '姓名', '邮箱', '粉丝数', '国家', '地区资料状态', '来源名单', '初判优先级', '推荐合作', '初判依据', '人工审核状态'];
  downloadCsv(header, seed.map(item => [displayTime(decisions[item.handle]?.at), item.handle, item.url, item.name || item.handle, item.email || '', item.followers || '', item.country || '', item.shippingStatus || '', item.source || '', item.priority || '', item.recommended ? '是' : '否', item.reason || '', status(item.handle) === 'approved' ? '通过' : status(item.handle) === 'rejected' ? '不通过' : '待审核']), `${config.brand}_完整审核记录.csv`);
};

function exportBackup() {
  const url = URL.createObjectURL(new Blob([JSON.stringify({datasetId:config.datasetId,decisions,exportedAt:nowText()},null,2)],{type:'application/json'}));
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = `${config.datasetId}-backup-${Date.now()}.json`;
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url),30000);
}
$('backupBtn').onclick = exportBackup;
$('retryBtn').onclick = () => ready ? persistDecisions() : restoreDecisions();
$('importBtn').onclick = () => { if (ready) $('backupFile').click(); };
$('backupFile').onchange = async event => {
  const file = event.target.files[0];
  if (!file) return;
  try {
    const value = JSON.parse(await file.text());
    if (value.datasetId !== config.datasetId || Object.keys(value.decisions || {}).some(handle => !validHandles.has(handle))) throw new Error('名单不一致');
    const incoming = validateDecisions(value.decisions);
    const conflicts = Object.keys(incoming).filter(handle => decisions[handle] && decisions[handle].status !== incoming[handle].status).length;
    if (!confirm(`导入 ${Object.keys(incoming).length} 条记录，其中 ${conflicts} 条与当前状态不同。确认以导入记录覆盖对应账号？将先下载当前备份。`)) return;
    exportBackup();
    history.push(Object.keys(incoming).map(handle => ({handle,value:decisions[handle] || null})));
    for (const [handle,item] of Object.entries(incoming)) changeDecision(handle,item);
    persistDecisions();
    render();
  } catch (error) { alert(`未导入：${error.message}`); }
  finally { event.target.value = ''; }
};
window.addEventListener('beforeunload', event => { if (Object.keys(dirty).length) { event.preventDefault(); event.returnValue = ''; } });

render();
restoreDecisions();
