#!/bin/sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
if ! command -v node >/dev/null 2>&1; then
  printf '%s\n' 'Node.js is required. Ask Codex to locate an existing Node runtime.' >&2
  exit 1
fi
exec node server.mjs
