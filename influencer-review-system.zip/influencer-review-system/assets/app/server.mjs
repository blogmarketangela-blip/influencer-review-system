import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const config = JSON.parse(await fs.readFile(path.join(root,'config.json'),'utf8'));
if (!/^[a-z0-9][a-z0-9_-]{0,79}$/.test(config.datasetId)) throw new Error('Invalid datasetId');
const port = Number(process.env.PORT || config.port);
const handles = new Set(JSON.parse(await fs.readFile(path.join(root,'resources.json'),'utf8')).map(x => x.handle));
const backups = path.join(root,'review_backups',config.datasetId);
const latest = path.join(backups,'latest.json');
let queue = Promise.resolve();
async function readState() {
  try {
    const state = JSON.parse(await fs.readFile(latest,'utf8'));
    if (state.datasetId !== config.datasetId) throw new Error('Wrong dataset');
    return state;
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
    return { datasetId: config.datasetId, decisions: {}, updatedAt: null };
  }
}
const json = (res,status,body) => { res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(body)); };
const allowed = new Set(['index.html','app.js','styles.css','overrides.css','data.js']);
const mime = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8'};
export const server = http.createServer(async (req,res) => {
  try {
    if (![`127.0.0.1:${port}`,`localhost:${port}`].includes(req.headers.host)) return json(res,403,{error:'Invalid host'});
    const url = new URL(req.url,`http://${req.headers.host}`);
    if (req.method === 'GET' && url.pathname === '/api/health') return json(res,200,{datasetId:config.datasetId,brand:config.brand});
    if (req.method === 'GET' && url.pathname === '/api/review-state') { await queue;return json(res,200,await readState()); }
    if (req.method === 'POST' && url.pathname === '/api/review-state') {
      if (req.headers.origin && ![`http://127.0.0.1:${port}`,`http://localhost:${port}`].includes(req.headers.origin)) return json(res,403,{error:'Invalid origin'});
      if (!req.headers['content-type']?.startsWith('application/json')) return json(res,415,{error:'JSON required'});
      let body = '';
      for await (const chunk of req) { body += chunk; if (Buffer.byteLength(body) > 2_000_000) return json(res,413,{error:'Too large'}); }
      let parsed;
      try { parsed = JSON.parse(body); } catch { return json(res,400,{error:'Invalid JSON'}); }
      const changes = parsed.changes;
      if (parsed.datasetId !== config.datasetId || !changes || typeof changes !== 'object' || Array.isArray(changes)) return json(res,400,{error:'Invalid dataset or changes'});
      for (const [handle,value] of Object.entries(changes)) {
        if (!handles.has(handle) || !value || !['pending','approved','rejected'].includes(value.status) || typeof value.at !== 'string' || !Number.isFinite(Date.parse(value.at))) return json(res,400,{error:'Invalid decision'});
      }
      const operation = queue.then(async () => {
        const state = await readState();
        for (const [handle,value] of Object.entries(changes)) state.decisions[handle] = {status:value.status,at:value.at};
        state.updatedAt = new Date().toISOString();
        await fs.mkdir(backups,{recursive:true});
        const suffix = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
        const content = JSON.stringify(state,null,2);
        await fs.writeFile(path.join(backups,`review-${suffix}.json`),content,{flag:'wx'});
        const temp = path.join(backups,`latest-${suffix}.tmp`);
        await fs.writeFile(temp,content);
        await fs.rename(temp,latest);
        return state;
      });
      queue = operation.catch(() => {});
      return json(res,200,await operation);
    }
    if (!['GET','HEAD'].includes(req.method)) return json(res,405,{error:'Method not allowed'});
    const file = url.pathname === '/' ? 'index.html' : url.pathname.slice(1);
    if (!allowed.has(file)) return json(res,404,{error:'Not found'});
    const bytes = await fs.readFile(path.join(root,file));
    res.writeHead(200,{'Content-Type':mime[path.extname(file)] || 'application/octet-stream','Cache-Control':'no-store'});
    res.end(req.method === 'HEAD' ? undefined : bytes);
  } catch (error) { console.error(error);json(res,500,{error:'Read or save failed; original state retained'}); }
}).listen(port,'127.0.0.1',() => console.log(`http://127.0.0.1:${port}/ dataset=${config.datasetId}`));
