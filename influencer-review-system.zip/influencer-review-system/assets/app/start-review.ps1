$ErrorActionPreference = 'Stop'
$config = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'config.json') -Raw | ConvertFrom-Json
$url = 'http://127.0.0.1:' + $config.port + '/'
$health = $url + 'api/health'
$running = $null
try { $running = Invoke-RestMethod $health -TimeoutSec 2 } catch {}
if ($running) {
    if ($running.datasetId -ne $config.datasetId) { throw 'Port belongs to another dataset. Choose another port without stopping that service.' }
} else {
    $connection = Get-NetTCPConnection -LocalPort $config.port -State Listen -ErrorAction SilentlyContinue
    if ($connection) { throw 'Port occupied by another service. Update config.json with a free port.' }
    $node = (Get-Command node -ErrorAction Stop).Source
    $env:PORT = [string]$config.port
    Start-Process -FilePath $node -ArgumentList 'server.mjs' -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $PSScriptRoot 'server-output.log') -RedirectStandardError (Join-Path $PSScriptRoot 'server-error.log')
    $started = $false
    for ($attempt = 0; $attempt -lt 10; $attempt++) {
        Start-Sleep -Milliseconds 300
        try {
            $running = Invoke-RestMethod $health -TimeoutSec 1
            if ($running.datasetId -eq $config.datasetId) { $started = $true; break }
        } catch {}
    }
    if (-not $started) { throw 'Startup failed. Check server-error.log.' }
}
Start-Process $url
