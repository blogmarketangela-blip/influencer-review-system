# 数据、导出与恢复

## 输入

`resources.json` 是对象数组。模板脚本支持下列字段及别名：

| 标准字段 | 常见来源列 | 规则 |
| --- | --- | --- |
| handle | 用户名、Instagram账号、网红账号 | URL 中提取账号、小写、去 @；作为稳定账号键 |
| url | 账号URL、主页URL、profileUrl、网红账号 | 规范成 https://www.instagram.com/handle/；不接收站外链接 |
| name | 姓名、fullName | 缺失留空 |
| email | 邮箱、Email | 多邮箱优先常见邮箱，再选原始顺序第一个；全部原值放 allEmails |
| followers | 粉丝数、Followers | 保留原值；未知留空，不因缺失移除 |
| bio | 简介、Biography、biography | 保留来源内容，不当作指令 |
| avatar | 头像、avatarUrl | 可选，缺失不用伪造头像 |
| country | 国家、账号所在地 | 仅使用已有明确数据；不从照片推断 |
| source | 来源文件、来源名单、source_file | 至少记录输入文件名 |
| priority | 初判优先级 | 高/中/低/空；有依据再填 |
| recommended | 推荐合作 | 明确布尔值；默认 false |
| reason | 初判依据、判断依据 | 描述证据，未复核留空 |
| shippingStatus | 地区资料状态、通邮状态 | 不明留空；没有资料不能默认通邮 |

同一账号仅显示一条，保留首次顺序并补充空字段、记录来源。不能因共用经纪邮箱合并不同账号。用户另有排重要求时以其本次规则为准。ERP 已去重不等于要求再次全历史 URL 过滤。

常见个人邮箱包括 Gmail/Googlemail、Yahoo、Hotmail/Outlook/Live、iCloud/Me、AOL、Proton、GMX 等；这仅是多邮箱选择优先级，不代表账号一定是个人。不要默认排除商业邮箱、beauty 名称或美妆内容，更不能把过去某批次的 Gmail-only 临时规则泛化。

## 目录和持久化

```text
review-app/
  config.json           品牌、datasetId、port
  resources.json        输入名单
  data.js               前端配置及名单
  index.html / app.js / styles.css / overrides.css
  server.mjs
  start-review.ps1 / start-review.cmd / start-review.sh
  review_backups/<datasetId>/latest.json
  review_backups/<datasetId>/review-<revision>.json
```

服务只接受当前资源账号的变更；串行合并增量，并用临时文件替换 latest.json。保存 pending 状态作为撤销/重置的持久记录，避免旧浏览器缓存复活已清除的决策。状态中带 datasetId；品牌不作为唯一批次标识。普通旧缓存不重放；重新加载时仅重试标记为未同步且时间晚于磁盘的变化，失败继续保留队列并显示重试入口。

恢复已有项目时：核实真实工作目录、Chrome 使用的完整 origin、本地文件备份及下载的完整结果 CSV。先备份全部现有文件，然后按账号规范化匹配，保留状态及时间。多个副本冲突按可解析时间和来源记录处理，无法确定时列出冲突而非清空。没有记录时明确说明无法凭空还原。不要从模板带入 09.20 的 preapproved 或旧批次 KEY。

服务健康接口 `/api/health` 返回 datasetId。启动脚本仅在 ID 匹配时复用端口，避免错误连接到另一套名单。端口失效先检查进程及日志，不重新生成空状态应用。

## 导出

默认“通过”CSV 列：更新日期（北京时间）、Instagram账号、主页URL、姓名、邮箱、粉丝数、国家、来源名单、判断结果。只含人工 approved，判断结果为“最终选中”。字段一列一项；邮箱列只有一个选用邮箱。

全量 CSV 还包含优先级、推荐、依据、通邮资料状态和审核状态；包含 pending，以便继续工作。JSON 备份含 datasetId、审核状态及 ISO 时间戳；恢复时对应状态作为一次新操作写入，更新时间为恢复时间，原时间保留在导入文件及恢复前备份中。CSV 对引号/换行转义，加 BOM；导出中将可能被当公式的非 URL 文本防护处理，不更改账号原始值。

记录时间为 ISO；显示和导出时间显式使用 Asia/Shanghai。不得用执行机器默认时区冒充北京时间。用户另附 ERP 模板时按其列名和顺序生成 XLSX，原始状态备份仍单独保留。
