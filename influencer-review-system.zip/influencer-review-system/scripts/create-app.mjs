import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const [out, input, brand = '红人', datasetId, portText = '4173'] = process.argv.slice(2);
const port = Number(portText);
if (!out || !input || !/^[a-z0-9][a-z0-9_-]{0,79}$/.test(datasetId ?? '') || !Number.isInteger(port) || port < 1024 || port > 65535) {
  throw new Error('Usage: node create-app.mjs output-dir resources.json BRAND stable-dataset-id [port]');
}
const target = path.resolve(out);
try { if ((await fs.readdir(target)).length) throw new Error('Target must be empty; existing review systems must be updated without replacing state.'); }
catch (error) { if (error.code !== 'ENOENT') throw error; }
const source = JSON.parse(await fs.readFile(input, 'utf8'));
if (!Array.isArray(source) || !source.length) throw new Error('Input must be a nonempty resource array.');
const domains = /^(gmail\.com|googlemail\.com|yahoo\.[a-z.]+|hotmail\.[a-z.]+|outlook\.[a-z.]+|live\.[a-z.]+|icloud\.com|me\.com|aol\.com|proton\.me|protonmail\.com|gmx\.[a-z.]+)$/i;
const get = (r, ...keys) => keys.map(k => r[k]).find(v => v !== undefined && v !== null && v !== '') ?? '';
const unique = new Map();
for (const row of source) {
  const raw = String(get(row, 'url', 'profileUrl', '账号URL', '主页URL', '网红账号', 'handle', 'username', '用户名', 'Instagram账号')).trim();
  const handle = (raw.match(/^(?:https?:\/\/)?(?:www\.)?instagram\.com\/([a-z0-9._]+)\/?(?:[?#].*)?$/i)?.[1] ?? raw.replace(/^@/, '')).toLowerCase();
  if (!/^[a-z0-9._]{1,30}$/.test(handle) || ['p','reel','reels','stories','explore','accounts'].includes(handle)) throw new Error(`Invalid Instagram account: ${raw}`);
  const allEmails = String(get(row, 'allEmails', 'all_emails', '全部邮箱', 'email', 'Email', '邮箱'));
  const emails = [...new Set(allEmails.match(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/gi) ?? [])];
  const item = {
    handle, url: `https://www.instagram.com/${handle}/`,
    name: get(row,'name','fullName','姓名'), email: emails.find(e => domains.test(e.split('@')[1])) ?? emails[0] ?? '', allEmails,
    followers: get(row,'followers','Followers','粉丝数'), bio: get(row,'bio','biography','Biography','简介'),
    avatar: get(row,'avatar','avatarUrl','头像'), source: get(row,'source','source_file','来源文件','来源名单') || path.basename(input),
    country: get(row,'country','国家','账号所在地'), category: get(row,'category','分类'),
    priority: get(row,'priority','初判优先级'), recommended: [true,'是'].includes(get(row,'recommended','推荐合作')),
    reason: get(row,'reason','初判依据','判断依据'), shippingStatus: get(row,'shippingStatus','通邮状态','地区资料状态'), sourceRows: 1,
  };
  if (!['','高','中','低'].includes(item.priority)) item.priority = '';
  const old = unique.get(handle);
  if (old) {
    for (const [key,value] of Object.entries(item)) if (old[key] === '' && value !== '') old[key] = value;
    old.source = [...new Set([old.source,item.source])].join('；');
    old.sourceRows++;
  } else unique.set(handle,item);
}
const resources = [...unique.values()];
const config = { brand, datasetId, port };
const template = fileURLToPath(new URL('../assets/app/', import.meta.url));
await fs.cp(template, target, { recursive: true });
await fs.writeFile(path.join(target,'config.json'),JSON.stringify(config,null,2));
await fs.writeFile(path.join(target,'resources.json'),JSON.stringify(resources,null,2));
await fs.writeFile(path.join(target,'data.js'),`window.REVIEW_CONFIG=${JSON.stringify(config)};\nwindow.BERLOOK_DATA=${JSON.stringify(resources)};\n`);
console.log(JSON.stringify({target,resources:resources.length,inputRows:source.length,url:`http://127.0.0.1:${port}/`},null,2));
